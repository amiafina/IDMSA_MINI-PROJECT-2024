-- phpMyAdmin SQL Dump
-- version 5.3.0-dev+20230109.7cde53ed0d
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2025 at 02:39 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dewanmakan`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(5) NOT NULL,
  `nama_pengguna` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `nama_pengguna`, `password`) VALUES
(1, 'Admin', 'Admin1234');

-- --------------------------------------------------------

--
-- Table structure for table `aduanpelajar`
--

CREATE TABLE `aduanpelajar` (
  `nama_pelajar` varchar(500) NOT NULL,
  `dorm` varchar(500) NOT NULL,
  `waktu_makan` varchar(500) NOT NULL,
  `aduan` varchar(500) NOT NULL,
  `bukti_aduan` varchar(500) NOT NULL,
  `penambahbaikan` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pelajarsakit`
--

CREATE TABLE `pelajarsakit` (
  `nama_pelajar` varchar(100) NOT NULL,
  `no_telefon` varchar(100) NOT NULL,
  `dorm` varchar(100) NOT NULL,
  `gambar_mc` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pelajarsakit`
--

INSERT INTO `pelajarsakit` (`nama_pelajar`, `no_telefon`, `dorm`, `gambar_mc`) VALUES
('Naura Binti Zainal', '0143245456', 'Siti Aisyah 1', '6727d2576afea.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`password`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
