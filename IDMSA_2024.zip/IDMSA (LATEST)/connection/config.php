<!-- untuk buat connection dengan database dalam php -->

<!-- start untuk memulakan connection -->
<?php
$connect = mysqli_connect('localhost','root','','dewanmakan')
or die('failed to connect db....');
?>